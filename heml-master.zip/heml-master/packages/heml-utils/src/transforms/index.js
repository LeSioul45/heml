import trueHide from './trueHide'
import convertProp from './convertProp'
import ieAlignFallback from './ieAlignFallback'
import fallbackFor from './fallbackFor'

export default { trueHide, convertProp, ieAlignFallback, fallbackFor }
